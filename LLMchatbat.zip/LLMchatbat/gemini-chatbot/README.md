# ✦ Gemini AI Chatbot

A modern, responsive, production-quality AI chatbot application powered by the Google Gemini API with a Node.js + Express backend proxy for secure API key handling.

---

## 🌟 Overview

The **Gemini AI Chatbot** delivers a smooth,ChatGPT/Gemini-inspired user experience with clean typography, code block highlighting, multi-turn chat history saved in `localStorage`, dark/light themes, and real-time backend API integration.

It enforces security best practices by completely isolating the Google Gemini API key on the Node.js backend. The API key is never exposed to frontend code or client network requests.

---

## 🚀 Features

- **🔒 Secure API Proxy**: All requests are handled via Node.js/Express. API keys are safely kept inside `backend/.env`.
- **🎨 Modern Responsive UI**: Glassmorphic styling, smooth micro-animations, mobile drawer sidebar, dark and light theme toggle.
- **💬 Smart Conversational Flow**: User messages right-aligned; Gemini AI messages left-aligned with markdown parsing (bold, bullet lists, tables, headers).
- **💻 Syntax-Highlighted Code Blocks**: Automatic syntax highlighting with single-click "Copy Code" button.
- **📋 Copy & Regenerate**: Copy full AI responses with visual "Copied!" feedback, or regenerate the last AI output.
- **🛑 Stop Generation**: Cancel active requests in-flight using `AbortController`.
- **⏳ Real-time Typing Indicator**: Animated "Gemini is thinking..." state while waiting for API responses.
- **💾 Local Storage Persistence**: Save, rename, switch between, and clear chat history directly in the browser.
- **✨ Empty State Welcome Screen**: Beautiful landing screen with instant 1-click example prompts.
- **🛡️ Graceful Error UI**: User-friendly handling for rate limits, network outages, and backend key configuration issues with 1-click retry.

---

## 🛠️ Technology Stack

- **Frontend**: HTML5, Vanilla CSS3 (Custom Properties & Glassmorphic Design System), Vanilla JavaScript (ES6+), Marked.js, Highlight.js.
- **Backend**: Node.js, Express.js, CORS, Dotenv.
- **API**: Google Gemini REST API (`gemini-2.5-flash` / `gemini-3.6-flash`).

---

## 📂 Folder Structure

```
gemini-chatbot/
├── frontend/
│   ├── index.html       # Single-page modern interface
│   ├── style.css        # Responsive dark/light design system
│   └── script.js        # Chat management, storage & backend API logic
├── backend/
│   ├── server.js        # Express proxy server & Gemini API caller
│   ├── package.json     # Node.js dependencies
│   └── .env             # Private API key configuration (GIT IGNORED)
├── .gitignore           # Git ignore file for secrets & node_modules
└── README.md            # Comprehensive project documentation
```

---

## 🔑 How to Obtain a Gemini API Key

1. Visit [Google AI Studio](https://aistudio.google.com/).
2. Sign in with your Google account.
3. Click on **Get API Key** or **Create API Key in new project**.
4. Copy your newly generated API key string.

---

## ⚙️ How to Configure `.env`

Create a `.env` file inside the `backend/` directory:

```env
GEMINI_API_KEY=your_actual_gemini_api_key_here
GEMINI_MODEL=gemini-2.5-flash
PORT=5000
```

> **Note**: Replace `your_actual_gemini_api_key_here` with your key from Google AI Studio.

---

## 📦 Installation & Setup

### 1. Install Backend Dependencies

Navigate to the `backend` directory and install the required NPM packages:

```bash
cd backend
npm install
```

### 2. Start the Backend Server

Run the Express server:

```bash
node server.js
```

The server will start at: `http://localhost:5000`

---

## 💻 Running the Frontend

You can run the frontend using any static web server (such as VS Code **Live Server**, `npx serve`, or opening `index.html` directly in your browser).

Option 1: Using VS Code Live Server
1. Open the project in VS Code.
2. Right-click `frontend/index.html`.
3. Select **Open with Live Server**.

Option 2: Direct browser access or serving via Node backend
- Direct: Open `frontend/index.html` in Chrome/Firefox/Edge.
- Via Node Server: Navigate to `http://localhost:5000` in your web browser (the backend automatically serves the `frontend` static directory).

---

## 🔒 Security Warning & Best Practices

> [!CAUTION]
> **NEVER COMMIT YOUR `.env` FILE OR API KEYS TO GITHUB OR ANY PUBLIC REPOSITORY!**

1. The `.env` file is listed in `.gitignore` to prevent accidental commits.
2. The Gemini API key remains strictly on the Node.js backend server.
3. The frontend communicates with the backend endpoint (`POST /api/chat`) and never sees the secret API key.
4. When deploying to production (e.g. Render, Vercel, Railway, AWS), set `GEMINI_API_KEY` in the hosting platform's Environment Variables panel.

---

## 🚀 Deployment Guide

To deploy safely in production:

1. **Deploy Backend**:
   - Host the `backend` code on a service like Render, Railway, Heroku, or AWS.
   - Set environment variables in the host dashboard (`GEMINI_API_KEY`, `GEMINI_MODEL`, `PORT`).
2. **Deploy Frontend**:
   - Host `frontend` on Vercel, Netlify, Cloudflare Pages, or GitHub Pages.
   - Update `API_BASE_URL` in `frontend/script.js` to point to your deployed backend URL.
