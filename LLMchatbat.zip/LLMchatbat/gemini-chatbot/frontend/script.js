/**
 * Gemini AI Chatbot - Frontend Script
 * Modern Vanilla JavaScript Application with Indian Standard Time (IST) Support
 */

(function () {
  'use strict';

  // API Backend URL Configuration
  const API_BASE_URL = window.location.origin.includes('5000') 
    ? '' 
    : 'http://localhost:5000';

  // Storage Keys
  const STORAGE_KEYS = {
    CHATS: 'gemini_chat_history',
    THEME: 'gemini_theme',
    CURRENT_CHAT_ID: 'gemini_current_chat_id'
  };

  // State Management
  let chats = {};
  let currentChatId = null;
  let activeAbortController = null;
  let isGenerating = false;

  // DOM Elements
  const elements = {
    sidebar: document.getElementById('sidebar'),
    sidebarOverlay: document.getElementById('sidebarOverlay'),
    sidebarToggleBtn: document.getElementById('sidebarToggleBtn'),
    sidebarCloseBtn: document.getElementById('sidebarCloseBtn'),
    newChatBtn: document.getElementById('newChatBtn'),
    headerNewChatBtn: document.getElementById('headerNewChatBtn'),
    historyList: document.getElementById('historyList'),
    clearHistoryBtn: document.getElementById('clearHistoryBtn'),
    settingsBtn: document.getElementById('settingsBtn'),
    themeToggleBtn: document.getElementById('themeToggleBtn'),
    
    welcomeScreen: document.getElementById('welcomeScreen'),
    chatMessages: document.getElementById('chatMessages'),
    messagesContainer: document.getElementById('messagesContainer'),
    
    userInput: document.getElementById('userInput'),
    sendBtn: document.getElementById('sendBtn'),
    stopBtn: document.getElementById('stopBtn'),
    
    statusText: document.getElementById('statusText'),
    settingsModal: document.getElementById('settingsModal'),
    modalCloseBtn: document.getElementById('modalCloseBtn'),
    modalClearStorageBtn: document.getElementById('modalClearStorageBtn'),
    backendStatusDesc: document.getElementById('backendStatusDesc'),
    backendBadge: document.getElementById('backendBadge'),
    activeModelDesc: document.getElementById('activeModelDesc'),
    toastContainer: document.getElementById('toastContainer')
  };

  // Indian Standard Time (IST) Formatting Helpers
  function formatIndianTime(timestamp = Date.now()) {
    const date = new Date(timestamp);
    return new Intl.DateTimeFormat('en-IN', {
      timeZone: 'Asia/Kolkata',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    }).format(date);
  }

  function formatIndianDateTime(timestamp = Date.now()) {
    const date = new Date(timestamp);
    return new Intl.DateTimeFormat('en-IN', {
      timeZone: 'Asia/Kolkata',
      day: '2-digit',
      month: 'short',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    }).format(date) + ' IST';
  }

  // Real-time IST Clock Update in Header
  function startIndianClock() {
    function updateClock() {
      const istTimeStr = formatIndianTime();
      if (elements.statusText && elements.statusText.textContent.includes('Online')) {
        elements.statusText.textContent = `Online • IST (${istTimeStr})`;
      }
    }
    updateClock();
    setInterval(updateClock, 30000);
  }

  // Initialize App
  function init() {
    setupMarkedOptions();
    loadTheme();
    loadChatHistory();
    setupEventListeners();
    checkBackendHealth();
    startIndianClock();

    if (!currentChatId || !chats[currentChatId]) {
      createNewChat(false);
    } else {
      switchChat(currentChatId);
    }

    autoResizeTextarea();
  }

  // Configure Marked parser for code blocks
  function setupMarkedOptions() {
    if (typeof marked !== 'undefined') {
      marked.setOptions({
        gfm: true,
        breaks: true,
        highlight: function (code, lang) {
          if (typeof hljs !== 'undefined' && lang && hljs.getLanguage(lang)) {
            try {
              return hljs.highlight(code, { language: lang }).value;
            } catch (err) {}
          }
          return code;
        }
      });
    }
  }

  // Event Listeners Setup
  function setupEventListeners() {
    // Sidebar Controls
    elements.sidebarToggleBtn.addEventListener('click', toggleSidebar);
    elements.sidebarCloseBtn.addEventListener('click', closeSidebar);
    elements.sidebarOverlay.addEventListener('click', closeSidebar);

    elements.newChatBtn.addEventListener('click', () => createNewChat(true));
    elements.headerNewChatBtn.addEventListener('click', () => createNewChat(true));
    elements.clearHistoryBtn.addEventListener('click', handleClearHistory);

    // Theme Toggle
    elements.themeToggleBtn.addEventListener('click', toggleTheme);

    // Input & Send
    elements.sendBtn.addEventListener('click', handleSendMessage);
    elements.stopBtn.addEventListener('click', handleStopGeneration);

    elements.userInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSendMessage();
      }
    });

    elements.userInput.addEventListener('input', autoResizeTextarea);

    // Example Prompt Cards
    document.querySelectorAll('.prompt-card').forEach(card => {
      card.addEventListener('click', () => {
        const promptText = card.getAttribute('data-prompt');
        if (promptText) {
          elements.userInput.value = promptText;
          autoResizeTextarea();
          elements.userInput.focus();
          handleSendMessage();
        }
      });
    });

    // Settings Modal
    elements.settingsBtn.addEventListener('click', () => {
      checkBackendHealth();
      elements.settingsModal.classList.add('active');
    });

    elements.modalCloseBtn.addEventListener('click', () => {
      elements.settingsModal.classList.remove('active');
    });

    elements.settingsModal.addEventListener('click', (e) => {
      if (e.target === elements.settingsModal) {
        elements.settingsModal.classList.remove('active');
      }
    });

    elements.modalClearStorageBtn.addEventListener('click', () => {
      if (confirm('Are you sure you want to clear all chat history and local settings?')) {
        localStorage.clear();
        chats = {};
        createNewChat(true);
        elements.settingsModal.classList.remove('active');
        showToast('All data has been reset.');
      }
    });
  }

  // Responsive Sidebar Handlers
  function toggleSidebar() {
    elements.sidebar.classList.toggle('open');
    elements.sidebarOverlay.classList.toggle('open');
  }

  function closeSidebar() {
    elements.sidebar.classList.remove('open');
    elements.sidebarOverlay.classList.remove('open');
  }

  // Theme Management
  function loadTheme() {
    const savedTheme = localStorage.getItem(STORAGE_KEYS.THEME) || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
  }

  function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem(STORAGE_KEYS.THEME, newTheme);
  }

  // Textarea Auto Resize
  function autoResizeTextarea() {
    const textarea = elements.userInput;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 160) + 'px';
  }

  // Chat History Management (localStorage)
  function loadChatHistory() {
    try {
      const storedChats = localStorage.getItem(STORAGE_KEYS.CHATS);
      chats = storedChats ? JSON.parse(storedChats) : {};
      currentChatId = localStorage.getItem(STORAGE_KEYS.CURRENT_CHAT_ID) || null;
      renderHistorySidebar();
    } catch (e) {
      console.error('Failed to load chats from localStorage:', e);
      chats = {};
    }
  }

  function saveChatHistory() {
    try {
      localStorage.setItem(STORAGE_KEYS.CHATS, JSON.stringify(chats));
      if (currentChatId) {
        localStorage.setItem(STORAGE_KEYS.CURRENT_CHAT_ID, currentChatId);
      }
      renderHistorySidebar();
    } catch (e) {
      console.error('Failed to save chats to localStorage:', e);
    }
  }

  function createNewChat(switchNow = true) {
    const id = 'chat_' + Date.now();
    chats[id] = {
      id,
      title: 'New Conversation',
      createdAt: Date.now(),
      messages: []
    };
    saveChatHistory();
    if (switchNow) {
      switchChat(id);
      if (window.innerWidth <= 768) closeSidebar();
    }
  }

  function switchChat(chatId) {
    if (!chats[chatId]) return;
    currentChatId = chatId;
    localStorage.setItem(STORAGE_KEYS.CURRENT_CHAT_ID, chatId);

    renderHistorySidebar();
    renderChatMessages();
    elements.userInput.focus();
  }

  function deleteChat(chatId, e) {
    e.stopPropagation();
    if (confirm('Delete this conversation?')) {
      delete chats[chatId];
      if (currentChatId === chatId) {
        const remainingKeys = Object.keys(chats);
        if (remainingKeys.length > 0) {
          switchChat(remainingKeys[remainingKeys.length - 1]);
        } else {
          createNewChat(true);
        }
      } else {
        saveChatHistory();
      }
      showToast('Conversation deleted');
    }
  }

  function handleClearHistory() {
    if (Object.keys(chats).length === 0) {
      showToast('No history to clear');
      return;
    }
    if (confirm('Clear all conversation history?')) {
      chats = {};
      createNewChat(true);
      showToast('Chat history cleared');
    }
  }

  function renderHistorySidebar() {
    elements.historyList.innerHTML = '';
    const sortedChatIds = Object.keys(chats).sort((a, b) => chats[b].createdAt - chats[a].createdAt);

    if (sortedChatIds.length === 0) {
      elements.historyList.innerHTML = `<div style="padding: 12px; font-size: 0.82rem; color: var(--text-muted); text-align: center;">No saved chats</div>`;
      return;
    }

    sortedChatIds.forEach(id => {
      const chat = chats[id];
      const item = document.createElement('div');
      item.className = `history-item ${id === currentChatId ? 'active' : ''}`;
      const istDateStr = formatIndianDateTime(chat.createdAt);
      
      item.innerHTML = `
        <div class="history-item-content">
          <span class="history-title" title="${escapeHtml(chat.title)}">${escapeHtml(chat.title)}</span>
          <span class="history-time">${istDateStr}</span>
        </div>
        <button class="btn-delete-history" title="Delete chat">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
          </svg>
        </button>
      `;

      item.addEventListener('click', () => switchChat(id));
      item.querySelector('.btn-delete-history').addEventListener('click', (e) => deleteChat(id, e));

      elements.historyList.appendChild(item);
    });
  }

  // Render Messages in Chat Container
  function renderChatMessages() {
    elements.chatMessages.innerHTML = '';
    const currentChat = chats[currentChatId];

    if (!currentChat || !currentChat.messages || currentChat.messages.length === 0) {
      elements.welcomeScreen.style.display = 'flex';
      return;
    }

    elements.welcomeScreen.style.display = 'none';

    currentChat.messages.forEach((msg, index) => {
      appendMessageToDOM(
        msg.role, 
        msg.content, 
        msg.timestamp || currentChat.createdAt, 
        index === currentChat.messages.length - 1 && msg.role === 'assistant'
      );
    });

    scrollToBottom();
  }

  // Append Message Bubble to DOM with Indian Time (IST) Timestamp
  function appendMessageToDOM(role, content, timestamp = Date.now(), isLatestAI = false) {
    const messageRow = document.createElement('div');
    messageRow.className = `message-row ${role === 'user' ? 'user' : 'ai'}`;
    const formattedIST = formatIndianTime(timestamp);

    if (role === 'user') {
      messageRow.innerHTML = `
        <div class="message-content-wrapper">
          <div class="message-bubble">${escapeHtml(content).replace(/\n/g, '<br>')}</div>
          <div class="message-time-badge">${formattedIST} IST</div>
        </div>
      `;
    } else {
      const parsedMarkdown = typeof marked !== 'undefined' ? marked.parse(content) : escapeHtml(content);

      messageRow.innerHTML = `
        <div class="message-avatar" title="Gemini AI">✦</div>
        <div class="message-content-wrapper">
          <div class="message-bubble">${parsedMarkdown}</div>
          <div class="message-footer-bar">
            <span class="message-time-badge">${formattedIST} IST</span>
            <div class="message-actions">
              <button class="action-btn btn-copy" title="Copy response">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
                <span>Copy</span>
              </button>
              ${isLatestAI ? `
              <button class="action-btn btn-regenerate" title="Regenerate response">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="1 4 1 10 7 10"></polyline>
                  <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path>
                </svg>
                <span>Regenerate</span>
              </button>` : ''}
            </div>
          </div>
        </div>
      `;

      // Copy Action
      const copyBtn = messageRow.querySelector('.btn-copy');
      if (copyBtn) {
        copyBtn.addEventListener('click', () => {
          navigator.clipboard.writeText(content).then(() => {
            copyBtn.querySelector('span').textContent = 'Copied!';
            showToast('Response copied to clipboard');
            setTimeout(() => {
              if (copyBtn.querySelector('span')) {
                copyBtn.querySelector('span').textContent = 'Copy';
              }
            }, 2000);
          }).catch(err => {
            console.error('Failed to copy text:', err);
          });
        });
      }

      // Regenerate Action
      const regenBtn = messageRow.querySelector('.btn-regenerate');
      if (regenBtn) {
        regenBtn.addEventListener('click', handleRegenerate);
      }

      enhanceCodeBlocks(messageRow);
    }

    elements.chatMessages.appendChild(messageRow);
  }

  // Format Code Blocks inside AI Messages
  function enhanceCodeBlocks(container) {
    const preBlocks = container.querySelectorAll('pre');
    preBlocks.forEach(pre => {
      const codeEl = pre.querySelector('code');
      if (!codeEl) return;

      let lang = 'code';
      codeEl.classList.forEach(cls => {
        if (cls.startsWith('language-')) {
          lang = cls.replace('language-', '');
        }
      });

      const header = document.createElement('div');
      header.className = 'code-block-header';
      header.innerHTML = `
        <span>${escapeHtml(lang)}</span>
        <button class="code-block-copy-btn">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
          </svg>
          <span>Copy code</span>
        </button>
      `;

      pre.insertBefore(header, codeEl);

      const copyCodeBtn = header.querySelector('.code-block-copy-btn');
      copyCodeBtn.addEventListener('click', () => {
        const rawCode = codeEl.textContent;
        navigator.clipboard.writeText(rawCode).then(() => {
          copyCodeBtn.querySelector('span').textContent = 'Copied!';
          setTimeout(() => {
            copyCodeBtn.querySelector('span').textContent = 'Copy code';
          }, 2000);
        });
      });
    });
  }

  // Send Message Logic
  async function handleSendMessage() {
    if (isGenerating) return;

    const messageText = elements.userInput.value.trim();
    if (!messageText) return;

    elements.userInput.value = '';
    autoResizeTextarea();

    const currentChat = chats[currentChatId];
    if (!currentChat) return;

    elements.welcomeScreen.style.display = 'none';

    if (currentChat.messages.length === 0) {
      currentChat.title = messageText.length > 30 ? messageText.substring(0, 30) + '...' : messageText;
    }

    const now = Date.now();
    currentChat.messages.push({ role: 'user', content: messageText, timestamp: now });
    saveChatHistory();
    appendMessageToDOM('user', messageText, now);
    scrollToBottom();

    await fetchGeminiResponse(messageText);
  }

  // Regenerate Response Logic
  async function handleRegenerate() {
    if (isGenerating) return;

    const currentChat = chats[currentChatId];
    if (!currentChat || currentChat.messages.length === 0) return;

    const lastMsg = currentChat.messages[currentChat.messages.length - 1];
    if (lastMsg.role === 'assistant') {
      currentChat.messages.pop();
    }

    const lastUserMsg = currentChat.messages[currentChat.messages.length - 1];
    if (!lastUserMsg || lastUserMsg.role !== 'user') return;

    saveChatHistory();
    renderChatMessages();

    await fetchGeminiResponse(lastUserMsg.content);
  }

  // Fetch Response from Node/Express Proxy Server
  async function fetchGeminiResponse(promptText) {
    setGeneratingState(true);

    const typingRow = document.createElement('div');
    typingRow.className = 'message-row ai typing-row';
    typingRow.id = 'typingIndicator';
    typingRow.innerHTML = `
      <div class="message-avatar">✦</div>
      <div class="message-content-wrapper">
        <div class="message-bubble">
          <div class="typing-indicator">
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <span style="font-size: 0.85rem; color: var(--text-muted); margin-left: 6px;">Gemini is thinking...</span>
          </div>
        </div>
      </div>
    `;
    elements.chatMessages.appendChild(typingRow);
    scrollToBottom();

    activeAbortController = new AbortController();

    try {
      const currentChat = chats[currentChatId];
      const historyPayload = currentChat.messages.slice(0, -1);

      const response = await fetch(`${API_BASE_URL}/api/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: promptText,
          history: historyPayload
        }),
        signal: activeAbortController.signal
      });

      removeTypingIndicator();

      if (!response.ok) {
        let errData = {};
        try {
          errData = await response.json();
        } catch (e) {}
        
        const errorMessage = errData.error || `Server responded with status ${response.status}`;
        renderErrorUI(errorMessage, promptText);
        setGeneratingState(false);
        return;
      }

      const data = await response.json();
      const replyText = data.reply || 'No response content generated.';
      const responseTime = Date.now();

      currentChat.messages.push({ role: 'assistant', content: replyText, timestamp: responseTime });
      saveChatHistory();

      appendMessageToDOM('assistant', replyText, responseTime, true);
      scrollToBottom();

    } catch (error) {
      removeTypingIndicator();

      if (error.name === 'AbortError') {
        showToast('Generation stopped by user');
      } else {
        console.error('Fetch error:', error);
        renderErrorUI('Network Error: Unable to reach the backend server. Please make sure the backend server is running on port 5000.', promptText);
      }
    } finally {
      setGeneratingState(false);
      activeAbortController = null;
    }
  }

  // Render Error UI Card inside Chat Stream
  function renderErrorUI(errorText, retryPrompt) {
    const errorRow = document.createElement('div');
    errorRow.className = 'message-row ai';
    errorRow.innerHTML = `
      <div class="message-avatar" style="background: #ef4444;">⚠️</div>
      <div class="message-content-wrapper">
        <div class="error-card">
          <div class="error-title">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="12" y1="8" x2="12" y2="12"></line>
              <line x1="12" y1="16" x2="12.01" y2="16"></line>
            </svg>
            <span>Response Failed</span>
          </div>
          <div>${escapeHtml(errorText)}</div>
          <button class="btn-retry">Retry Request</button>
        </div>
      </div>
    `;

    const retryBtn = errorRow.querySelector('.btn-retry');
    if (retryBtn) {
      retryBtn.addEventListener('click', () => {
        errorRow.remove();
        fetchGeminiResponse(retryPrompt);
      });
    }

    elements.chatMessages.appendChild(errorRow);
    scrollToBottom();
  }

  function removeTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (indicator) indicator.remove();
  }

  // Toggle Generating State UI
  function setGeneratingState(generating) {
    isGenerating = generating;
    elements.sendBtn.disabled = generating;
    elements.userInput.disabled = generating;

    if (generating) {
      elements.stopBtn.style.display = 'inline-flex';
      elements.sendBtn.style.display = 'none';
    } else {
      elements.stopBtn.style.display = 'none';
      elements.sendBtn.style.display = 'flex';
      elements.userInput.disabled = false;
      elements.userInput.focus();
    }
  }

  function handleStopGeneration() {
    if (activeAbortController) {
      activeAbortController.abort();
    }
  }

  // Backend Connection Health Checker
  async function checkBackendHealth() {
    try {
      const res = await fetch(`${API_BASE_URL}/api/health`);
      if (res.ok) {
        const data = await res.json();
        const istTimeStr = formatIndianTime();
        elements.statusText.textContent = `Online • IST (${istTimeStr})`;
        elements.backendStatusDesc.textContent = `Connected to http://localhost:5000`;
        elements.backendBadge.textContent = 'Connected';
        elements.backendBadge.style.background = 'rgba(16, 185, 129, 0.15)';
        elements.backendBadge.style.color = '#10b981';
        if (data.configuredModel) {
          elements.activeModelDesc.textContent = data.configuredModel;
        }
      } else {
        throw new Error('Health check returned non-200');
      }
    } catch (e) {
      elements.statusText.textContent = 'Backend Offline';
      elements.backendStatusDesc.textContent = 'Disconnected from server';
      elements.backendBadge.textContent = 'Offline';
      elements.backendBadge.style.background = 'rgba(239, 68, 68, 0.15)';
      elements.backendBadge.style.color = '#ef4444';
    }
  }

  // Utility Helpers
  function scrollToBottom() {
    requestAnimationFrame(() => {
      elements.messagesContainer.scrollTop = elements.messagesContainer.scrollHeight;
    });
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2.5">
        <polyline points="20 6 9 17 4 12"></polyline>
      </svg>
      <span>${escapeHtml(message)}</span>
    `;

    elements.toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(20px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // Start App
  document.addEventListener('DOMContentLoaded', init);

})();
