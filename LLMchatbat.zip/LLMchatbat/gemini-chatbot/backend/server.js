const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');

// Load environment variables from .env file in backend directory
dotenv.config({ path: path.join(__dirname, '.env') });

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// List of fallback models in order of priority if configured model is deprecated or unavailable
const FALLBACK_MODELS = [
  'gemini-3.6-flash',
  'gemini-3.5-flash',
  'gemini-flash-latest',
  'gemini-3.1-flash-lite',
  'gemini-3.7-flash'
];

// Health Check Endpoint
app.get('/api/health', (req, res) => {
  const apiKeyConfigured = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim() !== '');
  res.json({
    status: 'ok',
    server: 'Gemini AI Chatbot Backend',
    apiKeyConfigured,
    configuredModel: process.env.GEMINI_MODEL || 'gemini-2.5-flash'
  });
});

// Chat Endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;

    // 1. Validate Input
    if (!message || typeof message !== 'string' || !message.trim()) {
      return res.status(400).json({ 
        error: 'Message content is required and must be a non-empty string.' 
      });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    const configuredModel = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

    if (!apiKey || !apiKey.trim()) {
      return res.status(500).json({ 
        error: 'Backend Configuration Error: GEMINI_API_KEY is missing or empty in backend/.env' 
      });
    }

    // 2. Prepare Payload for Gemini REST API
    let contents = [];

    if (Array.isArray(history) && history.length > 0) {
      contents = history.map(item => ({
        role: item.role === 'user' ? 'user' : 'model',
        parts: [{ text: item.content || item.text || '' }]
      }));
      
      const lastContent = contents[contents.length - 1];
      if (!lastContent || lastContent.role !== 'user' || lastContent.parts[0]?.text !== message.trim()) {
        contents.push({
          role: 'user',
          parts: [{ text: message.trim() }]
        });
      }
    } else {
      contents = [
        {
          role: 'user',
          parts: [{ text: message.trim() }]
        }
      ];
    }

    // Format current Indian Standard Time (IST) dynamically for AI context
    const currentIST = new Intl.DateTimeFormat('en-IN', {
      timeZone: 'Asia/Kolkata',
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: '2-digit',
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(new Date()) + ' IST';

    const requestBody = {
      contents,
      systemInstruction: {
        parts: [
          { 
            text: `You are Gemini AI, an exceptionally efficient, intelligent, and helpful AI assistant specialized in answering all local (regional, cultural, travel, food, government schemes, geography, business, everyday local life) and global technical queries.

Current Real-Time Reference in India: ${currentIST} (Asia/Kolkata timezone).

Key Operational Guidelines:
1. Real-time Indian Date & Time Awareness: When asked about current time, today's date, day, or current time in India/local region, refer accurately to the current Indian Standard Time provided above (${currentIST}).
2. Local Expertise: Provide accurate, detailed, and helpful answers for all local questions—including regional culture, famous places, local foods, local transport, state/national government schemes, regional history, local news/topics, and everyday practical guidance.
3. Multilingual & Regional Dialects: Respond fluently in the language, script, or dialect used by the user (English, Tamil, Tanglish, Hindi, Telugu, Malayalam, etc.).
4. High Efficiency & Structure: Give direct, well-organized answers using bullet points, bold emphasis, structured headers, and clean formatting so information is easy to skim and digest.
5. Code & Professional Help: Write production-quality code, step-by-step solutions, and structured advice when asked technical, business, or educational questions.
6. Polite & Engaging Tone: Maintain a warm, encouraging, helpful, and solution-oriented personality at all times.` 
          }
        ]
      },
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 2048
      }
    };

    // Helper function to invoke Gemini REST API
    async function callGeminiAPI(modelName) {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${apiKey}`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody)
      });
      const data = await response.json();
      return { response, status: response.status, data };
    }

    // Try configured model first, followed by fallbacks if 404 or deprecated
    const modelsToTry = [configuredModel, ...FALLBACK_MODELS.filter(m => m !== configuredModel)];
    let result = null;
    let lastError = null;

    for (const modelCandidate of modelsToTry) {
      try {
        const attempt = await callGeminiAPI(modelCandidate);
        if (attempt.response.ok && attempt.data?.candidates?.[0]?.content?.parts?.[0]?.text) {
          result = {
            reply: attempt.data.candidates[0].content.parts[0].text,
            modelUsed: modelCandidate
          };
          break;
        } else {
          lastError = attempt;
          // If 404 or deprecated error message, try next fallback candidate model
          const is404 = attempt.status === 404;
          const isQuota = attempt.status === 429;
          const is503 = attempt.status === 503;
          const isDeprecated = attempt.data?.error?.message?.includes('no longer available') || attempt.data?.error?.message?.includes('experiencing high demand');

          if (!is404 && !isDeprecated && !isQuota && !is503) {
            // Non-recoverable error (e.g., Invalid API key)
            break;
          }
        }
      } catch (err) {
        console.error(`Error attempting model ${modelCandidate}:`, err.message);
      }
    }

    if (result) {
      return res.json({
        reply: result.reply,
        modelUsed: result.modelUsed
      });
    }

    // If no model succeeded, format friendly error response
    if (lastError && (lastError.data?.error || !lastError.response?.ok)) {
      const errData = lastError.data?.error || {};
      const msg = errData.message || 'Gemini API call failed.';
      const code = errData.code || lastError.status;

      console.error('Gemini API Error Response:', JSON.stringify(errData, null, 2));

      if (code === 401 || msg.includes('API_KEY_INVALID') || msg.toLowerCase().includes('key')) {
        return res.status(401).json({
          error: 'Invalid Gemini API key provided. Please check GEMINI_API_KEY in backend/.env.'
        });
      }

      if (code === 429 || msg.toLowerCase().includes('quota') || msg.toLowerCase().includes('rate limit')) {
        return res.status(429).json({
          error: 'Gemini API rate limit or quota exceeded. Please wait a moment and try again.'
        });
      }

      return res.status(code >= 400 && code < 600 ? code : 500).json({
        error: `Gemini API Error: ${msg}`
      });
    }

    return res.status(500).json({
      error: 'Failed to generate response from Gemini API. Please try again later.'
    });

  } catch (error) {
    console.error('Unhandled server error in /api/chat:', error);
    return res.status(500).json({
      error: 'Internal Server Error: An unexpected error occurred on the backend.'
    });
  }
});

// Serve static frontend files
const frontendPath = path.join(__dirname, '../frontend');
app.use(express.static(frontendPath));

app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(frontendPath, 'index.html'));
  }
});

app.listen(PORT, () => {
  console.log(`=================================================`);
  console.log(`🚀 Gemini AI Chatbot Server is running!`);
  console.log(`📡 URL: http://localhost:${PORT}`);
  console.log(`🔑 API Key Configured: ${process.env.GEMINI_API_KEY ? 'Yes' : 'No'}`);
  console.log(`🤖 Configured Model: ${process.env.GEMINI_MODEL || 'gemini-2.5-flash'}`);
  console.log(`=================================================`);
});
