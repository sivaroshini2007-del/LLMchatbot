# ✦ Gemini AI Chatbot

A modern, responsive, production-quality AI chatbot application powered by the Google Gemini API with a Node.js + Express backend proxy for secure API key handling.

Please see the [gemini-chatbot](./gemini-chatbot) folder for full source code and documentation.

## Quick Start

```bash
cd gemini-chatbot/backend
npm install
node server.js
```

Open `http://localhost:5000` in your web browser.
